
//ref: https://github.com/googleapis/nodejs-firestore
const Firestore = require('@google-cloud/firestore');
// const db = new Firestore({
//     projectId: 'cmpelkk',
//     keyFilename: '~/Documents/GoogleCloud/certs/cmpelkk-380e31c10ee7.json',
// });
const db = new Firestore();
const dbcollection = 'iottests';

async function testfirestore() {
    // Obtain a document reference.
    const document = db.doc('iottests/intro-to-firestore');

    // Enter new data into the document.
    await document.set({
        title: 'Welcome to Firestore',
        body: 'Hello World',
    });
    console.log('Entered new data into the document');

    // Update an existing document.
    await document.update({
        body: 'My first Firestore app',
    });
    console.log('Updated an existing document');

    // Read the document.
    let doc = await document.get();
    console.log('Read the document');

    // Delete the document.
    await document.delete();
    console.log('Deleted the document');
}

testfirestore();


//gcloud pubsub topics publish cmpeiotdevice1 --message "test pubsub"
/**
 * Background Cloud Function to be triggered by Pub/Sub.
 * This function is exported by index.js, and executed when
 * the trigger topic receives a message.
 *
 * @param {object} data The event payload.
 * @param {object} context The event metadata.
 */
exports.iotPubSub = (data, context) => {
    const pubSubMessage = data;
    const name = pubSubMessage.data
        ? Buffer.from(pubSubMessage.data, 'base64').toString()
        : 'World';

    console.log(`Hello, ${name}!`);
};


const escapeHtml = require('escape-html');
//curl -X POST HTTP_TRIGGER_ENDPOINT -H "Content-Type:application/json"  -d '{"name":"Jane"}'
/**
 * HTTP Cloud Function.
 *
 * @param {Object} req Cloud Function request context.
 *                     More info: https://expressjs.com/en/api.html#req
 * @param {Object} res Cloud Function response context.
 *                     More info: https://expressjs.com/en/api.html#res
 */
exports.httpApi = (req, res) => {
    const id = req.query.id;//req.params.id;
    console.log(`Get http query:, ${id}`);
    let bodydata;

    switch (req.get('content-type')) {
        // '{"name":"John"}'
        case 'application/json':
            ({ bodydata } = req.body);
            console.log("json content", JSON.stringify(bodydata));
            break;

        // 'John', stored in a Buffer
        case 'application/octet-stream':
            bodydata = req.body.toString(); // Convert buffer to a string
            break;

        // 'John'
        case 'text/plain':
            bodydata = req.body;
            break;

        // 'name=John' in the body of a POST request (not the URL)
        case 'application/x-www-form-urlencoded':
            ({ bodydata } = req.body);
            break;
    }
    //bodydata =req.body
    if (bodydata) {
        console.log(`Get body query:, ${bodydata}`);
    } else{
        bodydata = req.body ? req.body : 'nobody';
        console.log(`No body query: ${bodydata}`);
        console.log(bodydata);
    }
    switch (req.method) {
        case 'GET':
            const datalist = [];
            db.collection(dbcollection).get()
                .then((snapshot) => {
                    snapshot.forEach((doc) => {
                        console.log(doc.id, '=>', doc.data());
                        datalist.push({
                            id: doc.id,
                            data: doc.data()
                        });
                    });
                    res.status(200).send(datalist);
                })
                .catch((err) => {
                    console.log('Error getting documents', err);
                    res.status(405).send('Error getting data');
                });
            //res.status(200).send('Get request!');
            break;
        case 'POST':
            let docRef = db.collection(dbcollection).doc(id);
            console.log('POST Created doc ref');
            let setdoc = docRef.set({
                name: id,
                sensors: bodydata,
                time: new Date()
              });
            //res.status(200).send('Get Post request!');
            //sendCommand('cmpe181dev1', 'CMPEIoT1', 'cmpelkk', 'us-central1', 'test command');
            //res.status(200).send(`Post data: ${escapeHtml(bodydata || 'World')}!`);
            res.status(200).json({
                name: id,
                sensors: bodydata,
                time: new Date()
              })
            break;
        case 'PUT':
            let docdelRef = db.collection(dbcollection).doc(id);
            console.log('PUT Created doc ref');
            let deldoc = docdelRef.set({
                name: id,
                sensors: bodydata,
                time: new Date()
              });
            res.status(200).json({
                name: id,
                sensors: bodydata,
                time: new Date()
              })
            //res.status(403).send('Forbidden!');
            break;
        case 'DELETE':
            if (!id){
                res.status(405).send('query document id not available');
            }else{
                let deleteDoc = db.collection(dbcollection).doc(id).delete();
                res.status(200).send('Deleted!');
            }
            break;
        default:
            res.status(405).send({ error: 'Something blew up!' });
            break;
    }
    //res.send(`Hello ${escapeHtml(req.query.name || req.body.name || 'World')}!`);
};

exports.securehttpApi = (req, res) => {
    const id = req.query.id;
    console.log(`Get http query:, ${id}`);
    let bodydata = req.body ? req.body : 'nobody';
    console.log('Get http body:');
    console.log(bodydata);
    switch (req.method) {
        case 'GET':
            res.status(200).send('Get secure request!');
            break;
        case 'POST':
            res.status(200).send('Get secure request!');
            break;
        default:
            res.status(405).send({ error: 'Something blew up!' });
            break;
    }
}

const sendCommand = async (
    deviceId,
    registryId,
    projectId,
    cloudRegion,
    commandMessage
) => {
    // [START iot_send_command]
    // const cloudRegion = 'us-central1';
    // const deviceId = 'my-device';
    // const commandMessage = 'message for device';
    // const projectId = 'adjective-noun-123';
    // const registryId = 'my-registry';
    const iot = require('@google-cloud/iot');
    const iotClient = new iot.v1.DeviceManagerClient({
        // optional auth parameters.
    });

    const formattedName = iotClient.devicePath(
        projectId,
        cloudRegion,
        registryId,
        deviceId
    );
    const binaryData = Buffer.from(commandMessage);
    const request = {
        name: formattedName,
        binaryData: binaryData,
    };

    try {
        const responses = await iotClient.sendCommandToDevice(request);
        console.log('Sent command: ', responses[0]);
    } catch (err) {
        console.error('Could not send command:', err);
    }
    // [END iot_send_command]
};